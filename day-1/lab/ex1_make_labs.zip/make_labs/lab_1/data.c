#include <stdio.h>
#include "data.h"
void 
data(void) { 
    printf("Working on data.\n");
};
